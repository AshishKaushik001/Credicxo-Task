from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
	return render(request,'login.html')

def signup_data(request):
	username=request.POST.get('username','default')
    email=request.POST.get('email','default')
    password=request.POST.get('pwd','default')
    #repassword=request.POST.get('pswd','default')
    #mobile=request.POST.get('mobile','default')
    #gender=request.POST.get('gender','default') 
    exist=User.objects.filter(username=username)
    if exist:
    	return HttpResponse("User already exist")
    else:

    	print(username,email,password)
    	user=User.objects.create(username=username,password=password,email = email)
    	user.set_password(password)
    	#user.set_password(repassword)
    	user.save()
    	return render(request,'login.html',{})
def login_data(request):
	if request.method=="POST":
		Username=request.POST['username']
		Password=request.POST['pwd']
		print(Username,Password)
		user=authenticate(username=Username,password=Password)
		if user is not None:
			login(request, user)
			return render(request,'index.html',{})
		return HttpResponse("Invalid username or password")
